Compile 

	iverilog -o e16275_lab5_part2.vvp testbench.v reg_file.v

execute

	vvp e16275_lab5_part2.vvp
