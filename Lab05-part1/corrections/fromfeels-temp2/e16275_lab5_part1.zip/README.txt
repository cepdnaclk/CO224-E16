/*
    PereraALHE
    E16275
    lab5 part 1
    ALU Model SimplifiedVersion(Did not consider the single bit arithmatics)
*/

Compile using

	iverilog -o e16275_lab5_part1.vvp testbench.v alu.v

run using 

	vvp e16275_lab5_part1.vvp
